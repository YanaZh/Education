<?php
$objectArray = [
    "Cat",
    "dog",
    "mouse",
    "human",
    "bear",
    "elephant",
    "cow",
    "horse",
    "cockroach",
    "Chicken",
];
