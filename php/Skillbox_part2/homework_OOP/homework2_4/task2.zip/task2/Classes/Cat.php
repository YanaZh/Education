<?php


class Cat extends Item
{

}