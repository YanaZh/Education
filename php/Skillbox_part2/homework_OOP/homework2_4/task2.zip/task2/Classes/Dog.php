<?php

class Dog extends Item
{

}