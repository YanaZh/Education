<?php

class Human extends Item
{

}