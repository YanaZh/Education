<?php

class Chicken extends Item
{

}