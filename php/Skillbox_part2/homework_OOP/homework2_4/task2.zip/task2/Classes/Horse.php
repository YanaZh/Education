<?php

class Horse extends Item
{

}