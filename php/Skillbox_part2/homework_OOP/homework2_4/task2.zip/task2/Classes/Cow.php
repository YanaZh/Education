<?php

class Cow extends Item
{

}